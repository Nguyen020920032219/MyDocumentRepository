package vn.nguyentd.spring.demodependency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDependencyApplicationTests {

	@Test
	void contextLoads() {
	}

}
