package vn.nguyentd.spring.demodependency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoDependencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoDependencyApplication.class, args);
	}

}
